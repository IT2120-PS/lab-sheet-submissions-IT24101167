setwd("C:\\Users\\hansana619\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24101167")
##1
#i
#p(x<=10)
punif(10,min = 0, max = 30, lower.tail = TRUE)

#ii
#p(x>20) = 1 - p(x<=20)
1-punif(20,min = 0, max = 30, lower.tail = TRUE)
#or
punif(20,min = 0, max = 30, lower.tail = FALSE)

##2
#i
#p(x<=3)
pexp(3,rate = 0.5,lower.tail = TRUE)

#ii
#p(x>4) = 1-p(x<=4)
1-pexp(4,rate = 0.5,lower.tail = TRUE)
#or
pexp(4,rate = 0.5,lower.tail = FALSE)

#iii
#p(2<x<4) = p(x<=4)-p(x<=2)
pexp(4,rate = 0.5,lower.tail = TRUE)-pexp(2,rate = 0.5,lower.tail = TRUE)


##3
#i
#p(x>=37.9) = 1-p(x<37.9)
1-pnorm(37.9,mean = 36.8, sd = 0.4, lower.tail = TRUE)

#ii
#p(36.4<x<36.9) = p(x<=36.9)-p(x<=36.4)
pnorm(36.9,mean=36.8,sd=0.4,lower.tail=TRUE)-pnorm(36.4,mean=36.8,sd=0.4,lower.tail=TRUE)

#iii
#p(x<b) = 1.2% = 0.012
qnorm(0.012,mean=36.8,sd=0.4,lower.tail=TRUE)

#iv
#p(x>b) = 1.0% = 0.01
qnorm(0.01,mean=36.8,sd=0.4,lower.tail=FALSE)

##Exercise
##1
punif(25, min=0, max=40) - punif(10, min=0, max=40)   

##2
pexp(2, rate=1/3, lower.tail = TRUE)   

##3
#i
pnorm(130, mean = 100, sd = 15,lower.tail = FALSE)

#ii
qnorm(0.95, mean=100, sd=15) 









